<html lang="en">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap-theme.min.css">


    <!-- Font Icon -->
    
    
    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    <script>
body {
  background-image: url('bg-img/img1.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
}
</script>
</head>

<body>

    <div class="container">
    <div class="navbar">

    <div class="logo">
            
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="">Plants</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="">login</a></li>
                
            </ul>
        </nav>
       
    </div>
</div>


<div class="login">

        <section class="signup">
            <!-- <img src="images/signup-bg.jpg" alt=""> -->
            <div class="container">
                <div class="signup-content">
                <form action="loginaction.php"method="POST">
                        <h2 class="form-title">Login Here</h2>
                        <center>
                        <div class="form-group">
                        <label for="username">Username</label>
                            <input type="text" name="uname" id="username" placeholder="username"required />
                        </div>
                       

        
<div class="form-group">
        <label for="password">Password</label>
        <input type="password" placeholder="Password" id="password"name="password"required>
        </div>
        
       <div class="form-group">
             <input type="submit" value="login" name="submit"id="submit"class="btn btn-primary">
</div>
        <a href="../forgot.php">Forgot password?</a>
          </div>  
</div>
        
    </form>
</center>

<!-- partial -->
  
</body>
</html>
