
<?php

include("config.php");
include("header.php");
include("sidebar.php");
?>
<section id="main-content">
	<section class="wrapper">
		<div class="table-agile-info">
 <div class="panel panel-default">
    <div class="panel-heading">
     Product
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
      
          
        </thead>
        <tbody>
          <tr data-expanded="true">
<?php
if(isset($_GET["p_id"]))

{
	$pid=$_GET["p_id"];
	
	   
	$sql=mysqli_query($conn,"SELECT p.*,s.s_name as sname,c.c_name as cname  FROM tbl_plants p inner join tbl_sub s on s.s_id=p.s_id inner join tbl_cat c on c.c_id=s.c_id   WHERE p.p_status='0' AND p.p_id='$pid'");
    while($display=mysqli_fetch_array($sql))
    {
     echo "<tr>";
 
     echo "<td>Plant Name :</td>";
     echo "<td>".$display["p_name"]."</td>";
     echo "<tr>";
 
     echo "<td>Scientific Name :</td>";
     echo "<td>".$display["b_name"]."</td>";
 
     echo "</tr>";
     echo "<tr>";
     echo "<td>Category Name:</td>";
     echo "<td>".$display["cname"]."</td>";
     echo "</tr>";
     echo "<tr>";
     echo "<td>Subcategory Name:</td>";
     echo "<td>".$display["sname"]."</td>";
     echo "</tr>";
   
     
     echo "<td>Description:</td>";
     echo "<td>".$display["descp"]."</td>";
     echo "</tr>";
     echo "<tr>";
     
     
     echo "<td>Price:</td>";
     echo "<td>".$display["price"]."</td>";
     echo "</tr>";
    
     
   
 
 ?><tr>
     <td>Image:</td>
 <td><img src="image/<?php echo $display['image'];?>" alt="" height="500" width="350"></img></td>
</tr>
<?php
 }
    
}
?>
        </tbody>
        
        
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="../../vendors/typeahead.js/typeahead.bundle.min.js"></script>
  <script src="../../vendors/select2/select2.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/file-upload.js"></script>
  <script src="../../js/typeahead.js"></script>
  <script src="../../js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>