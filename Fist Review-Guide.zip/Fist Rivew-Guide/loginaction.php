<?php

include "config.php";
if(isset($_POST['submit'])){
$uname =  $_POST["uname"];
$password =  $_POST["password"];
//$abc=md5($_POST['password']);
$sql = mysqli_query($conn, "SELECT count(*) as total ,log_id from tbl_login WHERE username = '".$uname."' and   password='".$password."'");

$row = mysqli_fetch_array($sql);

if($row["total"] > 0){
        $_SESSION['uname']= $uname;
	
	header('location:home.php');
}
elseif($uname=="admin" && $password=="admin123#")
{
	header('location:..\Admin\index.php');
}
	else{
		
	?><script>
		if(window.confirm('Your username or password is error!!!! Try again'))
		{
			window.location.href='login.php';
		};</script>
	
	//<?php
	}
}
?>
