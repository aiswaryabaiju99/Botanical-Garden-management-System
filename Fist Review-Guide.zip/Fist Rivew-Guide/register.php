<?php
include("config.php");

if(isset($_POST['submit']))
{
$name = $_POST['name'];
$email = $_POST['email'];
$mob = $_POST['mob'];

$addr = $_POST['addr'];
$pincode = $_POST['pincode'];
$pwd = $_POST['pwd'];
$cpwd=$_POST['cpwd'];
//$abc=md5($_POST["password"]);
if(!preg_match("/^[a-zA-Z]+ [a-zA-Z]+$/", $name)){
    echo"<script>alert('Enter correct name');window.location='register.php'</script>";
}
if(!preg_match("/^[6789][0-9]{9}$/", $mob)){
    echo"<script>alert('Enter valid phone no');window.location='register.php'</script>";
}
if(!preg_match("/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/", $email)){
    echo"<script>alert('Enter valid email address');window.location='register.php'</script>";
}
if(!preg_match("/^[a-zA-Z0-9\s\,\''\-]*$/", $addr)){
    echo"<script>alert('Enter valid address');window.location='register.php'</script>";
}
if(!preg_match("/^(\d{4}|\d{6})$/", $pincode)){
    echo"<script>alert('Enter valid address');window.location='register.php'</script>";
}

$uppercase = preg_match('@[A-Z]@', $pwd);
$lowercase = preg_match('@[a-z]@', $pwd);
$number    = preg_match('@[0-9]@', $pwd);
$specialChars = preg_match('@[^\w]@', $pwd);

if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($pwd) < 8) {
    echo"<script>alert('Enter valid password');window.location='register.php'</script>";
}
if($pwd != $cpwd){
    echo"<script>alert('Passwords doesn't match');window.location='register.php'</script>";
}

$check_email = mysqli_query($conn, "SELECT email FROM `registeration` where email = '$email' ");
if(mysqli_num_rows($check_email) > 0){
  echo"<script>alert('Email Already exists');window.location='register.php'</script>";
}
else{
 $a = "INSERT INTO `registeration`( `name`, `email`, `phno`, `address`, `pincode`,`password` ) VALUES('$name','$email','$mob','$addr','$pincode','$pwd' )";
 $sql=mysqli_query($conn,$a);
$id = mysqli_insert_id($conn);
 $sql1 = "INSERT INTO `tbl_login` (`reg_id`,`username`,`password`) VALUES ('$id','$email','$pwd')";
 $qry = mysqli_query($conn,$sql1);

 if($qry==TRUE)
{
	echo "<script>alert('User registered Successfully!!');window.location='login.php'</script>";
}
else
{
	echo "Error".$sql."<br>".$conn->error;
}
$conn->close();
}
}
?>





<html>
<head>
    <meta charset="UTF-8">
    <title>Sign Up Form</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
   
</head>
<body>

    <div class="container">
    <div class="navbar">

    <div class="logo">
            
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="">Plants</a></li>
                <li><a href="">About</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="">login</a></li>
                
            </ul>
        </nav>
       
    </div>
</div>

	<div class="registerbox">
	<h1>Sign Up</h1><br>
	<form action="" method="POST">

       

<div class="input-group">
    <p>Full name</p>
	<input type="text" name="name" placeholder="Enter full name" id="contact-name" onkeyup="validateName()" required>
    <span id="name-error"></span>
</div>
<div class="input-group">
	<p>Email id</p>
	<input type="text" name="email" placeholder="Enter your mail id" id="contact-email" onkeyup="validateEmail()" required>
    <span id="email-error"></span>
</div>
<div class="input-group">
    <p>Mobile no</p>
	<input type="text" name="mob" placeholder="Enter mobile no" id="contact-phone" onkeyup="validatePhone()" required>
    <span id="phone-error"></span>
</div>
<div class="input-group">
    <p>Address</p>
	<input type="text" name="addr" placeholder="Enter address" id="contact-address" onkeyup="validateAddress()" required>
    <span id="address-error"></span>
</div>
<div class="input-group">
    <p>Pincode</p>
	<input type="text" name="pincode" placeholder="Enter pincode" id="contact-pincode" onkeyup="validatePincode()" required>
    <span id="pincode-error"></span>
</div>
<div class="input-group">
	<p>Password</p>
	<input type="password" name="pwd" placeholder="Enter password" id="contact-password" onkeyup="validatePassword()" required>
    <span id="password-error"></span>
</div>
<div class="input-group">
	<p>Confirm password</p>
	<input type="password" name="cpwd" placeholder="Confirm password" id="contact-confirmpwd" onkeyup="validateConfirmpwd()" required>
    <span id="confirmpwd-error"></span>
</div>
	<input type="submit" name="submit" value="Sign Up">
	</form>
	</div>
    <script src="script.js"></script>
</body>
</html>