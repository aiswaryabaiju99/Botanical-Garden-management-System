<?php 
require("config.php");
include("header.php");
include("sidebar.php");
if(isset($_POST['submit']))
{
$sid=$_POST['cid'];
$sname=$_POST['sname'];
$check_sname = mysqli_query($conn, "SELECT s_name FROM `tbl_sub` where s_name = '$sname' ");
if(mysqli_num_rows($check_sname) > 0){
    echo"<script>alert('SubCategory already present');window.location='addsubcat.php'</script>";
}
else{
$sqlInsert="INSERT INTO `tbl_sub`(`c_id`,`s_name`) VALUES('$sid','$sname')";
$queryInsert=mysqli_query($conn,$sqlInsert);
if($queryInsert)
{
  echo "<script>alert('Data inserted Successfully!!');window.location='viewsubcat.php'</script>";
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
<div class="main-panel">        
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card">
                
            <div class="col-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Add Sub Category</h4>
                  <p class="card-description">
                  Plants In Botanical Garden
                  </p>
                  <form class="forms-sample"method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                    <label for="categories">Choose Category</label>
                      <select class="form-control" id="categories" name="cid" >

<?php 
$sql="select * from tbl_cat";
$query=mysqli_query($conn,$sql);
while($row = mysqli_fetch_array($query)){ ?>
<option value="<?php echo $row['c_id'];?>"><?php echo ($row['c_name']); ?></option>
<?php }
?>
</select>
</div>
<div class="form-group">
                      <label for="exampleInputName1">Sub Category Name</label>
                      <input type="text" class="form-control"name="sname" require id="sname" placeholder="Sub Category"onchange="Validstr();"/>
                    </div>
                    <span id="msg1" style="color:red;"></span>
                        <script>
                    function Validstr() 
                    {
                    var val = document.getElementById('sname').value;
                     if (!val.match(/^[a-zA-Z ]*$/)) 
                     {
                     document.getElementById('msg1').innerHTML="Only alphabets are allowed ";
                       document.getElementById('sname').value = "";
                        return false;
                    }
                    document.getElementById('msg1').innerHTML=" ";
                   return true;
                    }
                   </script>
                    
                    
                    <button type="submit" name="submit"class="btn btn-primary mr-2">Submit</button>
                    <button class="btn btn-light">Cancel</button>
</div>
                  </form>
               
              </div>
            </div>
            
            </div>
            
            
                  </form>
                </div>
              </div>
            </div>
           
              </div>
            </div>
            <div class="col-md-6 grid-margin stretch-card">
             
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2021.  Premium <a href="https://www.bootstrapdash.com/" target="_blank">Bootstrap admin template</a> from BootstrapDash. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ml-1"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="../../vendors/typeahead.js/typeahead.bundle.min.js"></script>
  <script src="../../vendors/select2/select2.min.js"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/hoverable-collapse.js"></script>
  <script src="../../js/template.js"></script>
  <script src="../../js/settings.js"></script>
  <script src="../../js/todolist.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/file-upload.js"></script>
  <script src="../../js/typeahead.js"></script>
  <script src="../../js/select2.js"></script>
  <!-- End custom js for this page-->
</body>

</html>
